import datetime

from ckeditor_uploader.fields import RichTextUploadingField
from django.db import models
from django.db.models.signals import post_save

from ..collection.models_collection import Collection
from ..profile.models_profile import Profile
# ############## COURSE START ###############
from ..utils import Util


class CourseStatus(models.Model):
    """Status Course: Dev, Release"""
    name = models.CharField(max_length=64)

    def __str__(self):
        return f'{self.name}'


class Course(models.Model):
    """Course"""
    title = models.CharField(max_length=64)
    description = models.TextField(max_length=175, blank=True)
    price = models.IntegerField(default=0)
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    image_url = models.ImageField(blank=True, null=True, default=Util.DEFAULT_IMAGES.get('course'))
    duration_in_minutes = models.IntegerField(default=0)
    rating = models.FloatField(default=0)
    members_amount = models.IntegerField(default=0)
    max_progress = models.IntegerField(default=0)
    progress = models.IntegerField(default=0)
    status = models.ForeignKey(CourseStatus, blank=True, null=True, on_delete=models.SET_NULL)
    date_create = models.DateField(default=datetime.date.today)
    path = models.CharField(max_length=64, blank=True, unique=True)

    def __str__(self):
        return f'{self.profile.user.username}: {self.title}  [Course]'


def create_course(sender, **kwargs):
    """When a course is created, autofill fields"""
    if kwargs['created']:
        course = kwargs['instance']
        course.path = course.pk
        course_status = CourseStatus.objects.filter(name=Util.COURSE_STATUS_DEV_NAME)[0]
        course.status = course_status
        course.save()

        creator_collection = CreatorCollection.objects.create(course=course, creator=course.profile)
        creator_collection.save()

        course_info = CourseInfo.objects.create(course=course)
        course_info.save()

        course_main_info = CourseMainInfo.objects.create(course_info=course_info)
        course_main_info.save()

        course_stars = CourseStars.objects.create(course=course)
        course_stars.save()


post_save.connect(create_course, sender=Course)


class CreatorCollection(models.Model):
    """CreatorCollection"""
    creator = models.ForeignKey(Profile, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.creator}: \"{self.course.title}\""


# -------------- Page Course START ---------------
class CourseInfo(models.Model):
    """CourseInfo"""
    course = models.OneToOneField(Course, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.course.profile.user.username}: {self.course.title} [Info]"


class CourseMainInfo(models.Model):
    """CourseMainInfo"""
    course_info = models.OneToOneField(CourseInfo, on_delete=models.CASCADE)
    title_image_url = models.ImageField(blank=True, null=True)
    goal_description = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.course_info.course.profile.user.username}: {self.course_info.course.title} [MainInfo]"


class CourseFit(models.Model):
    """CourseFit"""
    course_info = models.ForeignKey(CourseInfo, on_delete=models.CASCADE)
    title = models.CharField(max_length=32, blank=True, null=True)
    description = models.TextField(max_length=256, blank=True, null=True)

    def __str__(self):
        return f"{self.course_info.course.profile.user.username}: {self.course_info.course.title}: {self.title} [Fit]"


class CourseStars(models.Model):
    """CourseStars"""
    course = models.OneToOneField(Course, on_delete=models.CASCADE)
    one_stars_count = models.IntegerField(default=0)
    two_stars_count = models.IntegerField(default=0)
    three_stars_count = models.IntegerField(default=0)
    four_stars_count = models.IntegerField(default=0)
    five_stars_count = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.course.profile.user.username}: {self.course.title} [Course Stars]"


class CourseSkill(models.Model):
    """CourseSkill"""
    course_info = models.ForeignKey(CourseInfo, on_delete=models.CASCADE)
    name = models.CharField(max_length=64)

    def __str__(self):
        return f"{self.course_info.course.profile.user.username}: {self.course_info.course.title}: {self.name} [Skill]"


# -------------- Page Course END -----------------


# ------------ Content Course START --------------
class Theme(models.Model):
    """The Course consists of Theme"""
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    title = models.CharField(max_length=64)
    image_url = models.ImageField(blank=True, null=True, default=Util.DEFAULT_IMAGES.get('theme'))
    max_progress = models.IntegerField(default=0)
    progress = models.IntegerField(default=0)
    path = models.CharField(max_length=64, blank=True, null=True)

    def __str__(self):
        return f"{self.course.profile.user.username}: {self.course.title} => {self.title} [Theme]"


def create_theme(sender, **kwargs):
    """When a course is created, autofill fields"""
    if kwargs['created']:
        theme = kwargs['instance']
        theme.path = theme.pk
        theme.save()


post_save.connect(create_theme, sender=Theme)


class Lesson(models.Model):
    """The Theme consists of Lesson"""
    theme = models.ForeignKey(Theme, on_delete=models.CASCADE)
    title = models.CharField(max_length=64)
    image_url = models.ImageField(blank=True, null=True, default=Util.DEFAULT_IMAGES.get('lesson'))
    max_progress = models.IntegerField(default=0)
    progress = models.IntegerField(default=0)
    path = models.CharField(max_length=64, blank=True, null=True)

    def __str__(self):
        return f"{self.theme.course.profile.user.username}: {self.theme.course.title}: {self.theme.title}: {self.title} [Lesson]"


def create_lesson(sender, **kwargs):
    """When a course is created, autofill fields"""
    if kwargs['created']:
        lesson = kwargs['instance']
        lesson.path = lesson.pk
        lesson.save()


post_save.connect(create_lesson, sender=Lesson)


class Step(models.Model):
    """The Lesson consists of Step"""
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    title = models.CharField(max_length=64)
    content = RichTextUploadingField(blank=True)
    max_progress = models.IntegerField(default=0)
    number = models.IntegerField(default=0)
    path = models.CharField(max_length=64, blank=True, null=True)

    def __str__(self):
        return f"{self.lesson.theme.course.profile.user.username} => {self.lesson.theme.course.title}: {self.lesson.theme.title} => {self.lesson.title} => {self.title} [Step]"


def create_step(sender, **kwargs):
    """When a course is created, autofill fields"""
    if kwargs['created']:
        step = kwargs['instance']
        step.path = step.pk
        step.save()


post_save.connect(create_step, sender=Step)


# ------------ Content Course END ----------------

# ------------ Profile to Course START --------------


class ProfileActionsLogs(models.Model):
    step = models.ForeignKey(Step, on_delete=models.SET_NULL, blank=True, null=True)
    profile = models.ForeignKey(Profile, on_delete=models.SET_NULL, blank=True, null=True)
    date_action = models.DateTimeField(default=datetime.datetime.now)

    def __str__(self):
        return f"{self.profile.user.username} => {self.step.lesson.theme.course.title}: {self.step.title} [{self.date_action}]"


class ProfileCourseRole(models.Model):
    """Role Profile to Course: Admin, User"""
    name = models.CharField(max_length=64)

    def __str__(self):
        return f"{self.name} [Role Profile to Course]"


class ProfileCourseStatus(models.Model):
    """Status Profile to Course: Being studied, Completed"""
    name = models.CharField(max_length=64)

    def __str__(self):
        return f"{self.name} [Status Profile to Course]"


class ProfileCourse(models.Model):
    """ProfileCourse"""
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    status = models.ForeignKey(ProfileCourseStatus, blank=True, null=True, on_delete=models.SET_NULL)
    progress = models.IntegerField(default=0)
    grade = models.IntegerField(blank=True, null=True)
    date_added = models.DateField(default=datetime.date.today)

    def __str__(self):
        status = None
        if self.status is not None:
            status = self.status.name
        return f"\"{self.profile.user.username}\" => \"{self.course.profile}: {self.course.title}\" [{status}]"


def create_profile_to_course(sender, **kwargs):
    """When a ProfileCourse is created, autofill fields"""
    if kwargs['created']:
        profile_course = kwargs['instance']
        if profile_course.status is None:
            profile_course.status = ProfileCourseStatus.objects.get(name=Util.PROFILE_COURSE_STATUS_STUDYING_NAME)
        profile_course.save()


post_save.connect(create_profile_to_course, sender=ProfileCourse)


class ProfileCourseCollection(models.Model):
    """Добавление курса в подборки"""
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    collection = models.ForeignKey(Collection, on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        course_title = "Добавленные"
        if self.collection is not None:
            course_title = f"{self.collection.profile}: {self.collection.title}"

        return f"\"{self.profile.user.username}\" => \"{self.course.profile}: {self.course.title}\" => \"{course_title}\""


class ProfileTheme(models.Model):
    """ProfileTheme"""
    theme = models.ForeignKey(Theme, on_delete=models.CASCADE)
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    progress = models.IntegerField(default=0)

    def __str__(self):
        return f"\"{self.profile.user.username}\" to \"{self.theme.course.title}: {self.theme.title}\""


class ProfileLesson(models.Model):
    """ProfileLesson"""
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    progress = models.IntegerField(default=0)

    def __str__(self):
        return f"\"{self.profile.user.username}\" to \"{self.lesson.theme.course.title}: {self.lesson.theme.title}: {self.lesson.title}\""


class ProfileStepStatus(models.Model):
    """Status Profile to Step course: Being studied, Completed"""
    name = models.CharField(max_length=64)

    def __str__(self):
        return f"{self.name} [Status Profile to Step course]"


class ProfileStep(models.Model):
    """ProfileStep"""
    step = models.ForeignKey(Step, on_delete=models.CASCADE)
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    status = models.ForeignKey(ProfileStepStatus, blank=True, null=True, on_delete=models.SET_NULL)
    progress = models.IntegerField(default=0)

    def __str__(self):
        return f"\"{self.profile.user.username}\" to \"{self.step.lesson.theme.course.title}: {self.step.lesson.theme.title}: {self.step.lesson.title}: {self.step.title}\""


def create_profile_to_course(sender, **kwargs):
    """When a ProfileStep is created, autofill fields"""
    if kwargs['created']:
        profile_step = kwargs['instance']
        profile_step.status = ProfileStepStatus.objects.filter(name=Util.PROFILE_COURSE_STATUS_STUDYING_NAME)[0]
        profile_step.save()


post_save.connect(create_profile_to_course, sender=ProfileStep)

# -------- Profile to Course END ------------
# ############## COURSE END #################
